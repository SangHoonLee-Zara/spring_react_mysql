export default interface FavoriteListItem {
    email: string;
    nickname: string;
    profileImage: string | null;
}
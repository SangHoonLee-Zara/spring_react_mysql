const favoriteListMock = [
    {
        "email": "zarad0525@naver.com",
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null
    },
    {
        "email": "zarad0525@naver.com",
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null
    },
    {
        "email": "zarad0525@naver.com",
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null
    },
    {
        "email": "zarad0525@naver.com",
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null
    },
    {
        "email": "zarad0525@naver.com",
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null
    },
];

export default favoriteListMock;
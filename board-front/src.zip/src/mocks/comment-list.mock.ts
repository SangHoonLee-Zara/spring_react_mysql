const commentListMock = [
    {
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null,
        "writeDatetime": "3분전",
        "content": "오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요 오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요"
    },
    {
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null,
        "writeDatetime": "3분전",
        "content": "오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요 오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요"
    },
    {
        "nickname": "안녕하세요 나는 웨인루니",
        "profileImage": null,
        "writeDatetime": "3분전",
        "content": "오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요 오늘 무슨 책을 읽을까? 재밌는 책을 읽고 싶은데 추천 부탁해요"
    }
];

export default commentListMock;
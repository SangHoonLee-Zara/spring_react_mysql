import GetPopularListResponseDto from './get-popular-list.response.dto';
import GetRelationListResponseDto from './get-relation-list.response.dto';

export type {
    GetPopularListResponseDto,
    GetRelationListResponseDto
}
import ResponseDto from "../response.dto";

export default interface PutFavoriteResponseDto extends ResponseDto {
    
}
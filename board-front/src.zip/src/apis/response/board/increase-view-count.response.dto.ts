import ResponseDto from "../response.dto";

export default interface IncreaseViewCountResponseDto extends ResponseDto {
    
}
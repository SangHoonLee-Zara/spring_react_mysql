import ResponseDto from "../response.dto";

export default interface PostCommentResponseDto extends ResponseDto {
    
}
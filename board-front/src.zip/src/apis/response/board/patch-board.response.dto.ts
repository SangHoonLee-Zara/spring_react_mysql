import ResponseDto from "../response.dto";

export default interface PatchBoardResponseDto extends ResponseDto{
    
}
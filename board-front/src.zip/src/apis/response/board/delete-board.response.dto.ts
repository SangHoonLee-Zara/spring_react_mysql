import ResponseDto from "../response.dto";

export default interface DeleteBoardResponseDto extends ResponseDto {
    
}
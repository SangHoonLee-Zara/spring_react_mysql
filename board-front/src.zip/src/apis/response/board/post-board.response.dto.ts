import ResponseDto from "../response.dto";

export default interface PostBoardResponseDto extends ResponseDto {
    
}
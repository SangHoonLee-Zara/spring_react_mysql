export default interface PostCommentRequestDto {
    content: string
}
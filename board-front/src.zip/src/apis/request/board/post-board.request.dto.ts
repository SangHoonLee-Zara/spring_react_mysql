export default interface PostBoardRequestDto {
    title: string;
    content: string;
    boardImageList: string[];
}
export default interface SignInRequestDto {
    email: string;
    password: string;
}